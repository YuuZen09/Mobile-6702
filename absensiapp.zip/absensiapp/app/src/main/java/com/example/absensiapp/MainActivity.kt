package com.example.absensiapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nim: String = "A12.2020.06457"
        val password: String = "09092002"

        val etnim: EditText = findViewById(R.id.nimuser)
        val etpass: EditText = findViewById(R.id.passworduser)

        val button: Button = findViewById(R.id.login)
        button.setOnClickListener {
            if (etnim.text.isEmpty() || etpass.text.isEmpty()) {
                Toast.makeText(this, "Isi Data Dengan Benar", Toast.LENGTH_SHORT).show()
            } else if (etnim.text.toString().equals(nim) && etpass.text.toString().equals(password)
            ) {
                val intent = Intent(this@MainActivity, aktivitasmenuutama::class.java)
                startActivity(intent)
            }
            else{
                Toast.makeText(this, "NIM Atau Password Salah", Toast.LENGTH_SHORT).show()
            }
        }

    }
}