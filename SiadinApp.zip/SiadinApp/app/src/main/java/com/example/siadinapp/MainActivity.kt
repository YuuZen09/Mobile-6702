package com.example.siadinapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class MainActivity : AppCompatActivity() {

    lateinit var session: SessionLogin

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val klikkulino =  findViewById(R.id.klikkulino) as ImageView
        klikkulino.setOnClickListener{
            val intent = Intent(this@MainActivity, aktivitaskulino::class.java)
            startActivity(intent)
        }
    }

    private fun setInitLayout(){
        session = SessionLogin(this)
        session.checkLogin()
    }

}