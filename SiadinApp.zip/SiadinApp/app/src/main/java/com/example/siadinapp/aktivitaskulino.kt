package com.example.siadinapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class aktivitaskulino : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_aktivitaskulino)
    }
}